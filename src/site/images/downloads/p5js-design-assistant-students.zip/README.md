# p5.js Design Assistant

A focused assistant for design students working with JavaScript and p5.js 1.x in global mode. It supports four modes:

- **Create** — create a new sketch.
- **Explain** — explain or annotate code without changing its behavior.
- **Fix** — identify a bug and make the smallest correction.
- **Edit** — modify or extend an existing sketch with minimal changes.

## Package contents

- `plugin.json` — portable plugin manifest.
- `skills/p5js-workflow/SKILL.md` — workflow instructions.
- `.codex-plugin/plugin.json` — compatibility manifest for clients that support this format.

## Using the package

This archive contains the plugin source files. It does not automatically install the plugin into a student's ChatGPT account, and a downloaded package is not a public listing. Import or install it only in a host that supports custom plugin/agent packages, following that host's current instructions. If the host does not support importing plugin packages, the skill file can be used as the instruction source in a compatible custom assistant setup.
